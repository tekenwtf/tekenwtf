---
title: Linha Plants da OX
linhaPlants: true
linha: Hidrata e da Brilho
linhaColor: "#FFF"
linhaTitleColor: "#D278A5"
headerBgColor: "#1b6453"
headerBg: "images/hidrata/header.jpg"
headerImg: "images/hidrata/destaque.png"
headerImgAux: "images/hidrata/destaque-img-auxiliar.png"
contentImg: "images/hidrata/conteudo.png"
contentImgAux: "images/hidrata/adorno-conteudo.png"
contentBg: "#B9549A"
contentText: "#FFFFFF"
benefitsBg: "#136537"
benefitsTitle: "#D278A5"
benefitsText: "#E2F7EE"
benefitsBorderColor: "#D278A5"
benefits: '"Fórmula composta por água de rosas e com 93% de ingredientes naturais",
          "Sela a cutícula e desembaraça os fios",
          "É vegana e não testada em animais",
          "É liberada sem silicones,  sulfatos, sal*, parabenos, corantes e óleos minerais (*sem adição de cloreto de sódio)",
          "Cabelos sem frizz e brilhantes todos os dias",
          "Seu cabelo mais bonito e saudável naturalmente, por muito mais tempo"'
benefitsImgs: '"images/hidrata/beneficio1.png",
               "images/hidrata/beneficio2.png",
               "images/hidrata/beneficio3.png",
               "images/hidrata/beneficio4.png",
               "images/hidrata/beneficio5.png",
               "images/hidrata/beneficio6.png"'
howToBg: "#E2E8E0"
howToColor: "#136537"
howToTitles: '"Shampoo",
              "Condicionador",
              "Creme multifuncional 2 em 1"'
howToTexts: '"Aplique o Shampoo OX Plants Hidrata & Dá Brilho nos cabelos massageando-os por alguns minutos. Enxágue e repita a aplicação.",
             "Após lavar os cabelos com shampoo, aplique o Condicionador OX Plants Hidrata & Dá Brilho nos cabelos ainda molhados, massageando-os. Deixe agir por alguns minutos e, em seguida, enxágue.",
             "O creme multifuncional 2 em 1 OX Plants Hidrata & Dá Brilho pode ser utilizado de duas maneiras: 1) Como Máscara de Tratamento: após o uso do shampoo e condicionador, aplique o produto mecha a mecha, deixe agir por 5 minutos e enxágue. 2) Como creme para pentear: após a lavagem, aplique o produto nos cabelos secos ou molhados em toda a extensão dos fios. Não é necessário enxaguar."'
howToImgs: '"images/hidrata/como-usar-1.png",
            "images/hidrata/como-usar-2.png",
            "images/hidrata/como-usar-3.png"'
---

A OX acredita que o essencial é o que fica. E nada mais essencial que um **shampoo com 93% de ingredientes naturais** que, somados à tecnologia do **Sistema OX Beleza Duradoura**, cuidam do couro cabeludo e hidratam os fios ao longo do dia.

O shampoo **OX Plants Hidrata & Dá Brilho** possui **água de rosas** em sua composição, o que sela a cutícula e desembaraça os fios, deixando-os sem frizz e brilhantes todos os dias. Com o shampoo OX Plants  **Hidrata & Dá Brilho** seu cabelo fica mais bonito e saudável naturalmente, por muito mais tempo.

     

Sua fórmula contém o exclusivo Sistema OX Beleza Duradoura de **liberação prolongada e é liberada, sem adição de cloreto de sódio, sulfatos, silicones, parabenos, corantes e óleos minerais**.

Além disso, toda a linha OX Plants é vegana e não testada em animais (certificada pela veganismo.org.br). A embalagem é sustentável pois realizamos 100% de compensação ambiental, em parceria com a Eureciclo.
