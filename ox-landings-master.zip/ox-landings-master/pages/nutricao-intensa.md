---
title: Linha Nutrição Intensa da OX
linha: Nutrição Intensa
linhaColor: "#000000"
linhaTitleColor: "#91582F"
headerBgColor: "#f7ecd6"
headerBg: "images/nutricao-intensa/header.jpg"
headerImg: "images/nutricao-intensa/destaque.png"
contentImg: "images/nutricao-intensa/conteudo.png"
contentBg: "#CDB187"
contentText: "#000000"
benefitsBg: "#91582f"
benefitsTitle: "#fff"
benefitsText: "#F7ECD6"
benefits: '"Óleos essenciais de cálamo, mirra e oliva.",
          "Nutre, dá brilho e movimento aos fios.",
          "Fórmula 100% vegana, sem testes em animais.",
          "Sem sal*, parabenos, silicones pesados e óleos minerais. <small>(*sem adição de cloreto de sódio)</small>",
          "Sistema OX de beleza duradoura: Tecnologia de liberação prolongada para fios mais bonitos, hidratados e perfumados por mais tempo.",
          "Fragrância fixadora concentrada."'
benefitsImgs: '"images/nutricao-intensa/beneficio1.png",
               "images/nutricao-intensa/beneficio2.png",
               "images/nutricao-intensa/beneficio3.png",
               "images/nutricao-intensa/beneficio4.png",
               "images/nutricao-intensa/beneficio5.png",
               "images/nutricao-intensa/beneficio6.png"'
howToBg: "#5a3a21"
howToColor: "#fff"
howToTitles: '"Shampoo",
              "Condicionador",
              "Creme para pentear",
              "Máscara de tratamento"'
howToTexts: '"Aplique o Shampoo OX Nutrição Intensa nos cabelos massageando-os por alguns minutos. Enxágue e repita a aplicação.",
             "Após lavar os cabelos com shampoo, aplique o Condicionador OX Nutrição Intensa nos cabelos ainda molhados, massageando-os. Deixe agir por alguns minutos e, em seguida, enxágue.",
             "Após lavar os cabelos com shampoo e condicionador, aplique o Creme para Pentear OX Nutrição Intensa nos cabelos secos ou molhados em toda a extensão dos fios. Não é necessário enxaguar. Para ação condicionante, aplicar após o shampoo e enxaguar.",
             "Após o uso do shampoo e condicionador, aplique a Máscara de Tratamento OX Nutrição Intensa em toda a extensão dos fios, mecha a mecha, do comprimento às pontas, evitando a raiz. Deixe agir por 5 minutos e, em seguida, enxágue."'
howToImgs: '"images/nutricao-intensa/como-usar-1.png",
            "images/nutricao-intensa/como-usar-2.png",
            "images/nutricao-intensa/como-usar-3.png",
            "images/nutricao-intensa/como-usar-4.png"'
---

**O Shampoo OX Nutrição Intensa** tem em sua composição exclusiva os **óleos essenciais de cálamo, mirra e oliva**. Com ação prolongada, penetra em todas as camadas dos fios, **nutrindo  e dando brilho e movimento** aos cabelos.

Além disso, todo shampoo OX conta com o exclusivo **Sistema OX Beleza Duradoura**, tecnologia exclusiva de **liberação prolongada** de ingredientes, garantido que se mantenham em contato com a fibra capilar por mais tempo, para uma beleza duradoura dos fios. 
 Com fragrância fixadora concentrada e apenas ingredientes essenciais para a beleza dos fios, esse produto é **livre de sal** (cloreto de sódio), **parabenos, silicones pesados e óleos minerais, além de ser  vegano, não testado em animais**.

 **Shampoo OX Nutrição Intensa é garantia de nutrição, hidratação e beleza aos cabelos ao longo do dia, dia após dia.
 Para melhores resultados, recomendamos o uso de toda a linha Nutrição Intensa.**
