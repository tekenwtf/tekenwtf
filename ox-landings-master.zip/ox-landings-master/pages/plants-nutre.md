---
title: Linha Plants da OX
linhaPlants: true
linha: Nutre e Cresce
linhaColor: "#FFF"
linhaTitleColor: "#D8862D"
headerBgColor: "#1b6453"
headerBg: "images/nutre/header.jpg"
headerImg: "images/nutre/destaque.png"
headerImgAux: "images/nutre/destaque-img-auxiliar.png"
contentImg: "images/nutre/conteudo.png"
contentImgAux: "images/nutre/adorno-conteudo.png"
contentBg: "#D8862D"
contentText: "#FFFFFF"
benefitsBg: "#136537"
benefitsTitle: "#D8862D"
benefitsText: "#E2F7EE"
benefitsBorderColor: "#D8862D"
benefits: '"Contém 93% de ingredientes naturais.",
          "Trata os fios danificados, contribuindo para o crescimento e fortalecimento dos cabelos.",
          "É vegana e não testada em animais.",
          "É liberada sem silicones,  sulfatos, sal*, parabenos, corantes e óleos minerais (*sem adição de cloreto de sódio).",
          "Com frutas poderosas (cranberry, gojiberry, mirtilo e mangostim) e óleos milagrosos (manteigas de cacau e manga e óleos de oliva, amêndoas, abacate, soja e algodão).",
          "Seu cabelo mais bonito e saudável naturalmente, por muito mais tempo"'
benefitsImgs: '"images/nutre/beneficio1.png",
               "images/nutre/beneficio2.png",
               "images/nutre/beneficio3.png",
               "images/nutre/beneficio4.png",
               "images/nutre/beneficio5.png",
               "images/nutre/beneficio6.png"'
howToBg: "#E2E8E0"
howToColor: "#136537"
howToTitles: '"Shampoo",
              "Condicionador",
              "Creme multifuncional 2 em 1"'
howToTexts: '"Aplique o Shampoo OX Plants Nutre & Cresce nos cabelos massageando-os por alguns minutos. Enxágue e repita a aplicação.",
             "Após lavar os cabelos com shampoo, aplique o Condicionador OX Plants Nutre & Cresce nos cabelos ainda molhados, massageando-os. Deixe agir por alguns minutos e, em seguida, enxágue.",
             "O creme multifuncional 2 em 1 OX Plants Nutre & Cresce pode ser utilizado de duas maneiras:
1) Como Máscara de Tratamento: após o uso do shampoo e condicionador, aplique o produto mecha a mecha, deixe agir por 5 minutos e enxágue. 2) Como creme para pentear: após a lavagem, aplique o produto nos cabelos secos ou molhados em toda a extensão dos fios. Não é necessário enxaguar."'
howToImgs: '"images/nutre/como-usar-1.png",
            "images/nutre/como-usar-2.png",
            "images/nutre/como-usar-3.png"'
---

A OX acredita que o essencial é o que fica. E nada mais essencial que um **shampoo com 93% de ingredientes naturais** que, somados à tecnologia do **Sistema OX Beleza Duradoura**, cuidam do couro cabeludo e hidratam os fios ao longo do dia.

O shampoo **OX Plants Nutre & Cresce** possui **frutas poderosas (cranberry, gojiberry, mirtilo e mangostim) e óleos milagrosos (manteigas de cacau e manga e óleos de oliva, amêndoas, abacate, soja e algodão)** que tratam os fios danificados, contribuindo para o crescimento e fortalecimento dos cabelos. Com o shampoo OX Plants Nutre & Cresce, **seu cabelo fica mais bonito e saudável naturalmente,** por muito mais tempo.

Sua fórmula contém o exclusivo Sistema OX Beleza Duradoura de **liberação prolongada e é liberada, sem adição de cloreto de sódio, sulfatos, silicones, parabenos, corantes e óleos minerais**.

Além disso, toda a linha OX Plants é vegana e não testada em animais (certificada pela veganismo.org.br). A embalagem é sustentável pois realizamos 100% de compensação ambiental, em parceria com a Eureciclo.
