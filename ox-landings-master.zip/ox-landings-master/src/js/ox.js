function setup(){

  var $content = document.getElementById('')

}
window.onload = setup()