---
title: Linha Reconstrução Profunda da OX
linha: Reconstrução Profunda
linhaColor: "#E5E5E5"
linhaTitleColor: "#E5E5E5"
headerBgColor: "#42629f"
headerBg: "images/reconstrução-profunda/header.jpg"
headerImg: "images/reconstrução-profunda/destaque.png"
contentImg: "images/reconstrução-profunda/conteudo.png"
contentBg: "#6B87B8"
contentText: "#FFFFFF"
benefitsBg: "#1F428A"
benefitsTitle: "#E0E6FE"
benefitsText: "#E0E6FE"
benefits: '"Combina tutano vegetal e aminoácidos para reconstruir a massa capilar",
          "Nutre e deixa os fios fortes e resistentes.",
          "Fórmula 100% vegana, sem testes em animais.",
          "Sem sal*, parabenos, silicones pesados e óleos minerais. <small>(*sem adição de cloreto de sódio)</small>",
          "Sistema OX de beleza duradoura: Tecnologia de liberação prolongada para fios mais bonitos, hidratados e perfumados por mais tempo.",
          "Fragrância fixadora concentrada."'
benefitsImgs: '"images/reconstrução-profunda/beneficio1.png",
               "images/reconstrução-profunda/beneficio2.png",
               "images/reconstrução-profunda/beneficio3.png",
               "images/reconstrução-profunda/beneficio4.png",
               "images/reconstrução-profunda/beneficio5.png",
               "images/reconstrução-profunda/beneficio6.png"'
howToBg: "#E0E6FE"
howToColor: "#1F428A"
howToTitles: '"Shampoo",
              "Condicionador",
              "Creme para pentear",
              "Máscara de tratamento"'
howToTexts: '"Aplique o  Shampoo OX Reconstrução Profunda nos 
cabelos massageando-os por alguns minutos. 
Enxágue e repita a aplicação.",
             "Após lavar os cabelos com shampoo, aplique o Condicionador OX Reconstrução Profunda nos cabelos ainda molhados, massageando-os. Deixe agir por alguns minutos e, em seguida, enxágue.",
             "Após lavar os cabelos com shampoo e condicionador, aplique o Creme para Pentear OX Reconstrução Profunda nos cabelos secos ou molhados em toda a extensão dos fios. Não é necessário enxaguar. Para ação condicionante, aplicar após o shampoo e enxaguar.",
             "Após o uso do shampoo e condicionador, aplique a Máscara de Tratamento OX Reconstrução Profunda em toda a extensão dos fios, mecha a mecha, do comprimento às pontas, evitando a raiz. Deixe agir por 5 minutos e, em seguida, enxágue."'
howToImgs: '"images/reconstrução-profunda/como-usar-1.png",
            "images/reconstrução-profunda/como-usar-2.png",
            "images/reconstrução-profunda/como-usar-3.png",
            "images/reconstrução-profunda/como-usar-4.png"'
---

**O Shampoo OX Reconstrução Profunda** combina o poder do **tutano vegetal e dos aminoácidos** que penetram em todas as camadas dos fios para reconstruir a massa capilar. Esse shampoo limpa o cabelo sem agredir e, graças à sua fórmula, **reconstrói e deixa os fios fortes** e resistentes por muito mais tempo.

Além disso, todo shampoo OX conta com o exclusivo **Sistema OX Beleza Duradoura**, tecnologia exclusiva de **liberação prolongada** de ingredientes, garantido que se mantenham em contato com a fibra capilar por mais tempo, para uma beleza duradoura dos fios. 
 Com fragrância fixadora concentrada e apenas ingredientes essenciais para a beleza dos fios, esse produto é **livre de sal** (cloreto de sódio), **parabenos, silicones pesados e óleos minerais, além de ser  vegano, não testado em animais**.

 Shampoo OX Reconstrução Profunda é garantia de reconstrução, hidratação e beleza aos cabelos ao longo do dia, dia após dia.
 Para melhores resultados, recomendamos o uso de toda a linha Recontrução Profunda.
