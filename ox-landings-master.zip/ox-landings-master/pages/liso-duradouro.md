---
title: Linha Liso Duradouro da OX
linha: Liso Duradouro 
linhaColor: "#FFFFFF"
linhaTitleColor: "#FFFFFF"
headerBgColor: "#713AA3"
headerBg: "images/liso-duradouro/header.jpg"
headerImg: "images/liso-duradouro/destaque.png"
contentImg: "images/liso-duradouro/conteudo.png"
contentBg: "#9694D1"
contentText: "#FFFFFF"
benefitsBg: "#A855D9"
benefitsTitle: "#fff"
benefitsText: "#E4CDFB"
benefits: '"Elastina vegetal para efeito liso duradouro.",
          "Elimina o frizz dos cabelos.",
          "Fórmula 100% vegana, sem testes em animais.",
          "Sem sal*, parabenos, silicones pesados e óleos minerais. <small>(*sem adição de cloreto de sódio)</small>",
          "Sistema OX de beleza duradoura: Tecnologia de liberação prolongada para fios mais bonitos, hidratados e perfumados por mais tempo.",
          "Fragrância fixadora concentrada."'
benefitsImgs: '"images/liso-duradouro/beneficio1.png",
               "images/liso-duradouro/beneficio2.png",
               "images/liso-duradouro/beneficio3.png",
               "images/liso-duradouro/beneficio4.png",
               "images/liso-duradouro/beneficio5.png",
               "images/liso-duradouro/beneficio6.png"'
howToBg: "#D5D3F4"
howToColor: "#8331B2"
howToTitles: '"Shampoo",
              "Condicionador"'                       
howToTexts: '"Aplique o Shampoo OX Liso Duradouro nos cabelos molhados massageando-os por alguns minutos. Enxágue e repita a aplicação.",
             "Após lavar os cabelos com shampoo, aplique o Condicionador OX Liso Duradouro nos cabelos ainda molhados, massageando-os. Deixe agir por alguns minutos e, em seguida, enxágue. "'
howToImgs: '"images/liso-duradouro/como-usar-1.png",
            "images/liso-duradouro/como-usar-2.png"'
           
---

**O Shampoo OX Liso Duradouro** proporciona um efeito liso aos seus cabelos graças à sua fórmula com **elastina vegetal**, penetrando em todas as camadas dos fios, **selando as cutículas capilares e eliminando o frizz** dos seus cabelos por muito mais tempo.
.

Além disso, todo shampoo OX conta com o exclusivo **Sistema OX Beleza Duradoura**, tecnologia exclusiva de **liberação prolongada** de ingredientes, garantido que se mantenham em contato com a fibra capilar por mais tempo, para uma beleza duradoura dos fios. 
 Com fragrância fixadora concentrada e apenas ingredientes essenciais para a beleza dos fios, esse produto é **livre de sal** (sem cloreto de sódio), **parabenos, silicones pesados e óleos minerais, além de ser  vegano, não testado em animais**.

Shampoo OX Liso Duradouro é garantia de cabelos lisos, com efeito antifrizz ao
longo do dia, dia após dia. 
Para melhores resultados, recomendamos o uso de toda a linha Liso Duradouro.
