---
title: Linha Reparação Completa da OX
linha: Reparação Completa
linhaColor: "#E4DFD0"
linhaTitleColor: "#000000"
headerBgColor: "#b59a87"
headerBg: "images/reparação-completa/header.jpg"
headerImg: "images/reparação-completa/destaque.png"
contentImg: "images/reparação-completa/conteudo.png"
contentBg: "#8A8A8C"
contentText: "#FFFFFF"
benefitsBg: "#000000"
benefitsTitle: "#D2B5A1"
benefitsText: "#E4DFD0"
benefitsBorderColor: "#457073"
benefits: '"Com arginina e argila negra, cria camada de proteção contra danos externos.",
          "Repara os danos e restaura os fios da raíz às pontas.",
          "Fórmula 100% vegana, sem testes em animais.",
          "Sem sal*, parabenos, silicones pesados e óleos minerais. <small>(*sem adição de cloreto de sódio)</small>",
          "Sistema OX de beleza duradoura: Tecnologia de liberação prolongada para fios mais bonitos, hidratados e perfumados por mais tempo.",
          "Fragrância fixadora concentrada."'
benefitsImgs: '"images/reparação-completa/beneficio1.png",
               "images/reparação-completa/beneficio2.png",
               "images/reparação-completa/beneficio3.png",
               "images/reparação-completa/beneficio4.png",
               "images/reparação-completa/beneficio5.png",
               "images/reparação-completa/beneficio6.png"'
howToBg: "#FEF9EB"
howToColor: "#000000"
howToTitleColor: "#000000"
howToTitles: '"Shampoo",
              "Condicionador",
              "Máscara de tratamento"'
howToTexts: '"Aplique o Shampoo OX Reparação Completa nos cabelos molhados massageando-os por alguns minutos. Enxágue e repita a aplicação.",
             "Após lavar os cabelos com shampoo, aplique o Condicionador OX Reparação Completa nos cabelos ainda molhados, massageando-os. Deixe agir por alguns minutos e, em seguida, enxágue.",
             "Após o uso do shampoo e condicionador, aplique a Máscara de Tratamento OX Reparação Completa em toda a extensão dos fios, mecha a mecha, do comprimento às pontas, evitando a raiz. Deixe agir por 5 minutos e, em seguida, enxágue."'
howToImgs: '"images/reparação-completa/como-usar-1.png",
            "images/reparação-completa/como-usar-2.png",
            "images/reparação-completa/como-usar-3.png"'
---

O **Shampoo OX Reparação Completa** possui formulação com **argila negra e a arginina**, que penetram profundamente nos fios criando uma **potente camada de proteção contra danos externos.**. 

Além disso, todo shampoo OX conta com o exclusivo **Sistema OX Beleza Duradoura**, com tecnologia exclusiva de **liberação prolongada** de ingredientes, garantido que se mantenham em contato com a fibra capilar por mais tempo, para uma beleza duradoura. Com fragrância fixadora concentrada e apenas ingredientes essenciais para a beleza dos fios, esse produto é livre de sal (sem adição de cloreto de sódio), **parabenos, silicones pesados e óleos minerais, além de ser 100% vegano, não testado em animais**.

Shampoo OX Reparação Completa é garantia de proteção, hidratação e beleza aos cabelos ao longo do dia, dia após dia. Para melhores resultados, recomendamos o uso de toda a linha Reparação Completa.
