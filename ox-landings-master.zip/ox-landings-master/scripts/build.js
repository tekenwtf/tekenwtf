const parseMD = require('parse-md').default
const getFiles = require('node-recursive-directory');
const fs = require('fs');
const markdown = require('markdown-wasm');
const path = require('path');
const rimraf = require('rimraf');
const Mustache = require('mustache');

function copyFileSync( source, target ) {

  var targetFile = target;

  // If target is a directory, a new file with the same name will be created
  if ( fs.existsSync( target ) ) {
      if ( fs.lstatSync( target ).isDirectory() ) {
          targetFile = path.join( target, path.basename( source ) );
      }
  }

  fs.writeFileSync(targetFile, fs.readFileSync(source));
}

function copyFolderRecursiveSync( source, target ) {
  var files = [];

  // Check if folder needs to be created or integrated
  var targetFolder = path.join( target, path.basename( source ) );
  if ( !fs.existsSync( targetFolder ) ) {
      fs.mkdirSync( targetFolder );
  }

  // Copy
  if ( fs.lstatSync( source ).isDirectory() ) {
      files = fs.readdirSync( source );
      files.forEach( function ( file ) {
          var curSource = path.join( source, file );
          if ( fs.lstatSync( curSource ).isDirectory() ) {
              copyFolderRecursiveSync( curSource, targetFolder );
          } else {
              copyFileSync( curSource, targetFolder );
          }
      } );
  }
}

function returnOxBenefits(metadata){
  if(!metadata.benefits){
    return false
  }
  var arr = [];
  var pattern = /".*?"/g;
  var html = '';
  var index = 0;
  while(current = pattern.exec(metadata.benefits)){
    arr[index] = {};
    arr[index].content = current[0].slice(1,-1)
    index++;
  }
  index = 0;
  while(current = pattern.exec(metadata.benefitsImgs)){
    arr[index].image = current[0].slice(1,-1)
    index++;
  }
  for (var index = 0; index < arr.length; index++) {
    const element = arr[index];
    html += `<li>
              <span><img src="${element.image}" /></span>
              <div>${element.content}</div>
            </li>`
    
  }
  return html;
}

function parseContent( content, part ){
  var html = markdown.parse(content)
  var parts = html.replace(/\n/g, "").split('</p><p>')

  if( part === 1 ){
    return parts[0]
  } else {
    var copy = parts.slice()
    var firstElement = copy.shift();
    return copy.join('')
  }
  console.log(parts); 
}

function calcItemsInStringArray(string){
  var pattern = /".*?"/g;
  var index = 0;
  var arr = []
  while(current = pattern.exec(string)){
    index++;
  }
  return index;
}

function returnOxHowTo(metadata){
  if(!metadata.howToTitles || !metadata.howToTexts){
    return false
  }
  var pattern = /".*?"/g;
  var html = '';
  var index = 0;
  var arr = []
  while(current = pattern.exec(metadata.howToTitles)){
    arr[index] = {}
    arr[index].title = current[0].slice(1,-1);
    index++;
  }
  index = 0;
  while(current = pattern.exec(metadata.howToTexts)){
    arr[index].content = current[0].slice(1,-1);
    index++;
  }
  index = 0;
  while(current = pattern.exec(metadata.howToImgs)){
    arr[index].image = current[0].slice(1,-1);
    index++;
  }

  for (var index = 0; index < arr.length; index++) {
    const element = arr[index];
    html += `<li>
              <span><img src="${element.image}" alt="${element.title}" /></span>
              <div>
                <h4>${index + 1} - <span>${element.title}</span></h4>
                ${element.content}
              </div>
            </li>`
    
  }
  return html;
}

(async () => {

    const files = await getFiles('./pages');
    const directory = './build/'
    //const tempUrl = `http://localhost/ox-landings/build/`;
    const tempUrl = `https://ox-landings.netlify.app/`;
    const timeStamp = new Date().getTime();
    const template = fs.readFileSync(`./src/templates/default.html`, 'utf8')

    // delete old files
    rimraf(`${directory}*`, function () { 
      console.log(directory, ' cleaned.'); 

      // copy from src folder
      copyFolderRecursiveSync('./src/images/', directory)
      copyFolderRecursiveSync('./src/css/', directory)
      copyFolderRecursiveSync('./src/js/', directory)

      // create html based on md files
      files.forEach(item => {
        const name = item.split('/').reverse()[0].split('.')[0]
        const directory = `./build/`
        const filename = (directory + name + '.html')
        const fileContents = fs.readFileSync(item, 'utf8')
        const { metadata, content } = parseMD(fileContents)
        
        let defaults = {
          baseUrl: tempUrl,
          timeStamp: timeStamp,
          content: markdown.parse(content),
          content1: parseContent(content, 1),
          content2: parseContent(content, 2),
          benefits: returnOxBenefits(metadata),
          howTo: returnOxHowTo(metadata),
          howToClass: calcItemsInStringArray(metadata.howToTitles) === 3 ? 'is-three-items' : 'default',
          logoClass: metadata.linhaPlants ? 'is-linha-plants' : 'is-default-logo',
          logoWrapperClass: metadata.linhaPlants ? 'plants-header' : 'default-header',
          linhaName: metadata.linhaPlants ? 'Linha Plants' : 'Linha',
          isLinhaPlants: Boolean(metadata.linhaPlants)
        }

        const output = Mustache.render(template, { 
          ...metadata, 
          ...defaults
        })

        fs.writeFile( 
          filename, 
          output, 
          function (err, file) {
            if (err) throw err;
            console.log(filename, ' saved!');
          }
        );

      });
    });

})()